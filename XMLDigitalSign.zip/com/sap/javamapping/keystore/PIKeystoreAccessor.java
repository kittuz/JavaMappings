package com.sap.javamapping.keystore;

import java.rmi.RemoteException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.UnrecoverableKeyException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.sap.aii.mapping.api.AbstractTrace;
import com.sap.aii.mapping.api.MappingTrace;
import com.sap.aii.utilxi.misc.api.BabelMessage;
import com.sap.aii.utilxi.misc.api.ResourceException;
import com.sap.engine.services.keystore.interfaces.KeystoreManagerWrapper;


public class PIKeystoreAccessor {
	
	private static MappingTrace TRACE;
	private static String myname = "XIKeystoreAccessor";

	static PIKeystoreAccessor instance = null;

    KeystoreManagerWrapper keystoreManager;
    Map keystores = null;	
	
    
    private PIKeystoreAccessor(MappingTrace absTr) throws ResourceException {
        final String SIGNATURE = "XIKeystoreAccessor()";
        TRACE = absTr;
        TRACE.addInfo("Creating " + myname + SIGNATURE);
        
        keystores = new HashMap();
        
        InitialContext ctx = null;
        try {
			ctx = new InitialContext();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        KeystoreManagerWrapper kmanager = null;
        try {
			kmanager = (KeystoreManagerWrapper)ctx.lookup("keystore");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}        
        
        keystoreManager = kmanager;

       }   
    
    /**
     * Get a key from AS Java keystore
     * 
     * @param view
     * @param alias
     * @param password
     * @return
     * @throws ResourceException
     */
    public Key getPrivateKey(String view, String alias, String password) throws ResourceException {
     final String SIGNATURE = "getPrivateKey()";
     TRACE.addInfo(SIGNATURE);
     KeyStore keystore = getKeystore(view);
     Key privateKey = null;
     try {
         privateKey = (Key) keystore.getKey(alias, password.toCharArray());
         if (privateKey == null) {
          throw new ResourceException(BabelMessage.createFromString("Key not found. alias=" + alias));
         }
     } catch (KeyStoreException e) {
    	 TRACE.addInfo("KeyStoreException " + SIGNATURE);
         throw new ResourceException(e);
     } catch (NoSuchAlgorithmException e) {
    	 TRACE.addInfo("NoSuchAlgorithmException " + SIGNATURE);
         throw new ResourceException(e);
     } catch (UnrecoverableKeyException e) {
    	 TRACE.addInfo("UnrecoverableKeyException " + SIGNATURE);
         throw new ResourceException(e);
     }
     TRACE.addInfo(SIGNATURE);
     return privateKey;
    }   
    
    public PublicKey getPublicKey(String view, String alias) throws ResourceException {
        final String SIGNATURE = "getPublicKey()";
        TRACE.addInfo(SIGNATURE);

        KeyStore keystore = getKeystore(view);
        PublicKey publicKey = null;
        try {
            publicKey = keystore.getCertificate(alias).getPublicKey();
            if (publicKey == null) {
            	
             throw new ResourceException(BabelMessage.createFromString("Key not found. alias=" + alias));
            }
        } catch (KeyStoreException e) {
        	
            throw new ResourceException(e);
        }
        
        return publicKey;

       }    
    
    /**
     * Get a keystore i.e. a view from AS Java
     * 
     * @param view
     * @return
     * @throws ResourceException
     */
    public KeyStore getKeystore(String view) throws ResourceException {
     final String SIGNATURE = "getKeystore()";
     TRACE.addInfo(SIGNATURE);
     KeyStore keystore;

     try {
         if (keystores.containsKey(view) == true) {
          keystore = (KeyStore) keystores.get(view);
          
         } else {
        	 TRACE.addInfo("Looking for Keystore " + view);
          keystore = keystoreManager.getKeystore(view);
          if (keystore == null) {
              throw new ResourceException(BabelMessage.createFromString("Keystore not found. view=" + view));
          }
          keystores.put(view, keystore);
          
         }
         TRACE.addInfo(SIGNATURE);
         return keystore;
     } catch (RemoteException e) {
    	 TRACE.addInfo("RemoteException " + SIGNATURE);
    	 throw new ResourceException(e);
	}
    }    
    
    
//  static method which will handle instances of this class - Singleton pattern  
    static public PIKeystoreAccessor getInstance(AbstractTrace absTr) throws ResourceException {
    	absTr.addInfo(myname);
    	if (instance == null) {
            instance = new PIKeystoreAccessor(absTr);
        }
           return instance;
       }
    }    