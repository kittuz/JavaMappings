package com.sap.javamapping.keystore;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.sap.aii.mapping.api.AbstractTrace;
import com.sap.aii.mapping.api.AbstractTransformation;
import com.sap.aii.mapping.api.StreamTransformationConstants;
import com.sap.aii.mapping.api.StreamTransformationException;
import com.sap.aii.mapping.api.TransformationInput;
import com.sap.aii.mapping.api.TransformationOutput;
import com.sap.aii.utilxi.misc.api.ResourceException;

public class XMLDigitalSign extends AbstractTransformation {
	
	private PIKeystoreAccessor keyAccessor;
	private AbstractTrace trace_pi = null;

	private Map param = null;
	String lineEnd = System.getProperty("line.separator");
	String keyStoreName = "";
	String keyViewName = "";
	String rootTagName	= "";
	

	
	public void transform(TransformationInput arg0, TransformationOutput arg1) throws StreamTransformationException {
		
		keyStoreName 	= arg0.getInputParameters().getString("keyStore_Name"); //WebServiceSecurity
		keyViewName 	= arg0.getInputParameters().getString("keyView_Name");//WSNDEA1234
		rootTagName 	= arg0.getInputParameters().getString("rootTag_Name"); //ns0:ApplicationRequest
		
		signByJava(arg0.getInputPayload().getInputStream(), arg1.getOutputPayload().getOutputStream(),getTrace());

	}    	     

	
	private void signByJava(InputStream in, OutputStream out, AbstractTrace absTr) {
		final String SIGNATURE = "signByJava()";

		try {
			keyAccessor = PIKeystoreAccessor.getInstance(absTr);
			
		} catch (ResourceException e) {
			e.printStackTrace();
		}
		
		KeyStore ks = null;
		
		try {
			ks = keyAccessor.getKeystore("WebServiceSecurity");
		
		} catch (ResourceException e) {
			e.printStackTrace();
		}
		
		java.security.cert.Certificate cert = null;
		try {
			cert = ks.getCertificate(keyViewName);
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
		}	
		X509Certificate x509Cert =  (X509Certificate) cert;
		
        // Create the signature factory for creating the signature.
        XMLSignatureFactory sigFactory = XMLSignatureFactory.getInstance("DOM", new org.jcp.xml.dsig.internal.dom.XMLDSigRI());
        
        Reference ref = null;
    	try {
			ref = sigFactory.newReference
				    ("", sigFactory.newDigestMethod(DigestMethod.SHA1, null),
			             Collections.singletonList
				      (sigFactory.newTransform
					(Transform.ENVELOPED, (TransformParameterSpec) null)), 
				     null, null);
		} catch (NoSuchAlgorithmException e) {
			absTr.addInfo("NoSuchAlgorithmException " + SIGNATURE);
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			absTr.addInfo("InvalidAlgorithmParameterException " + SIGNATURE);
			e.printStackTrace();
		}
			
    	
    	// Create the SignedInfo
    	SignedInfo si = null;
    	try {

			si = sigFactory.newSignedInfo
			    (sigFactory.newCanonicalizationMethod
			     (CanonicalizationMethod.INCLUSIVE, 
			      (C14NMethodParameterSpec) null), 
			     sigFactory.newSignatureMethod(SignatureMethod.RSA_SHA1, null),
			     Collections.singletonList(ref));
		} catch (NoSuchAlgorithmException e) {
			absTr.addInfo("NoSuchAlgorithmException " + SIGNATURE);
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			absTr.addInfo("InvalidAlgorithmParameterException " + SIGNATURE);
			e.printStackTrace();
		}    	
    	
     
//        // Create a KeyValue containing the RSA PublicKey that was generated
    	KeyInfoFactory kif = KeyInfoFactory.getInstance("DOM", new org.jcp.xml.dsig.internal.dom.XMLDSigRI());
        javax.xml.crypto.dsig.keyinfo.KeyValue kv = null;
        javax.xml.crypto.dsig.keyinfo.X509Data x509data = null;
        try {
        	
        	kv = kif.newKeyValue(keyAccessor.getPublicKey(keyStoreName, keyViewName));
        	x509data = kif.newX509Data(Collections.singletonList(x509Cert));
		} catch (KeyException e) {
			absTr.addInfo("KeyException " + SIGNATURE);
			e.printStackTrace();
		} catch (ResourceException e) {
			absTr.addInfo("ResourceException " + SIGNATURE);
			e.printStackTrace();
		}
        
    	// Create a KeyInfo and add the KeyValue to it
        KeyInfo ki = null;
        ArrayList keys = new ArrayList();
        keys.add(kv);
        keys.add(x509data);
        ki = kif.newKeyInfo(keys);
        
        
    	// Instantiate the document to be signed
    	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    	dbf.setNamespaceAware(true);
    	DocumentBuilder db = null;
    	Document origDoc = null;
    	Document gasdoc = null;
    	try {
    		db = dbf.newDocumentBuilder();
			origDoc = db.parse(in);
			gasdoc = db.newDocument();
			Node gasnode = gasdoc.importNode(origDoc.getElementsByTagName(rootTagName).item(0), true);
			gasdoc.appendChild(gasnode);
		} catch (SAXException e) {
			absTr.addInfo("SAXException " + SIGNATURE, e);
			e.printStackTrace();
		} catch (IOException e) {
			absTr.addInfo("IOException " + SIGNATURE, e);
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			absTr.addInfo("ParserConfigurationException " + SIGNATURE, e);
			e.printStackTrace();
		}        
        
        // Create a DOMSignContext and specify the RSA PrivateKey and
        // location of the resulting XMLSignature's parent element
    	DOMSignContext dsc = null;
		try {
			dsc = new DOMSignContext(keyAccessor.getPrivateKey(keyStoreName, keyViewName, ""), gasdoc.getDocumentElement());
			
		} catch (ResourceException e1) {
			absTr.addInfo("ResourceException " + SIGNATURE, e1);
			e1.printStackTrace();
		}  
    	
    	// Create the XMLSignature (but don't sign it yet)
		XMLSignature signature = sigFactory.newXMLSignature(si, ki);
    	
        // Marshal, generate (and sign) the enveloped signature
        try {
			signature.sign(dsc);
			absTr.addInfo("Document succesfully signed " + SIGNATURE);
		} catch (MarshalException e) {
			absTr.addInfo("MarshalException " + SIGNATURE, e);
			e.printStackTrace();
		} catch (XMLSignatureException e) {
			absTr.addInfo("XMLSignatureException " + SIGNATURE, e);
			e.printStackTrace();
		}    	
        
//      Create original document structure
        Document outDoc = db.newDocument();
        Node node = outDoc.importNode(origDoc.getFirstChild(), false);
        outDoc.appendChild(node);
        node = outDoc.importNode(gasdoc.getFirstChild(), true);
        outDoc.getDocumentElement().appendChild(node);
        
    	TransformerFactory tf = TransformerFactory.newInstance();
    	Transformer trans;
		try {
			trans = tf.newTransformer();
			trans.transform(new DOMSource(outDoc), new StreamResult(out));
		} catch (TransformerConfigurationException e) {
			absTr.addInfo("TransformerConfigurationException " + SIGNATURE, e);
			e.printStackTrace();
		} catch (TransformerException e) {
			absTr.addInfo("TransformerException " + SIGNATURE, e);
			e.printStackTrace();
		}		
	}
	
	public void setParameter(Map param) {
		this.param = param;
		trace_pi = (AbstractTrace) param.get(StreamTransformationConstants.MAPPING_TRACE);
	}

}
